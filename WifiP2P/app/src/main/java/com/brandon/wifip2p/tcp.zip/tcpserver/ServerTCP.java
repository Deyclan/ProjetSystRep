package com.brandon.wifip2p.tcpserver;

import android.widget.TextView;

import com.brandon.wifip2p.tcpclient.ClientTCP;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class ServerTCP implements Runnable {

    private boolean running = true;

    private int port;
    private static ServerSocket serverSocket;
    private TextView console;

    private final static int MAX_TCP_CLIENNT = 5;
    private List<ClientTCP> clientTCPs;

    private ClientTCP currentClientTCP;

    public ServerTCP(int port){
        this.port = port;
        clientTCPs = new ArrayList<>(MAX_TCP_CLIENNT);
    }

    public ServerTCP(int port, TextView console){
        this.port = port;
        clientTCPs = new ArrayList<>(MAX_TCP_CLIENNT);
        this.console = console;
    }

    public ServerTCP(int port, ClientTCP clientTCP){
        this.port = port;
        this.currentClientTCP = clientTCP;
    }

    @Override
    public void run(){
        try {
            serverSocket = new ServerSocket(port, 10);

            while (running){
                Socket inputClientSocket = serverSocket.accept();
                ClientTCP newClient = new ClientTCP(inputClientSocket,console);
                clientTCPs.add(newClient);
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void stop(){
        running = false;
    }



}
