package com.brandon.wifip2p.tcpserver;

import java.net.ServerSocket;
import java.net.Socket;

public class Server implements Runnable{

    private int port;
    private static ServerSocket serverSocket;

    public Server(int port){
        this.port = port;
    }

    @Override
    public void run() {
        try {
            serverSocket = new ServerSocket(port, 10);

            while (true){
                Socket inputClientSocket = serverSocket.accept();
                new Thread(new Connexion(inputClientSocket)).start();
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

}
