package com.brandon.wifip2p.tcpclient;

import android.os.AsyncTask;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Observable;

public class ClientTCP {

    private InetAddress address;
    private int port;
    private Socket socket;
    private InputStream in;
    private OutputStream out;
    private TextView console;

    private AsyncReciever asyncReciever;

    public ClientTCP(InetAddress address, int port){
        this.address = address;
        this.port = port;
        connect();
        asyncReciever = new AsyncReciever();
        asyncReciever.execute();
    }

    public ClientTCP(InetAddress address, int port, TextView console){
        this.address = address;
        this.port = port;
        this.console = console;
    }

    public ClientTCP(Socket socket, TextView console){
        this.socket = socket;
        this.address = socket.getInetAddress();
        this.port = socket.getPort();
        this.console = console;
    }

    private void connect() {
        try {
            socket = new Socket(address, port);
            in = socket.getInputStream();
            out = socket.getOutputStream();

            asyncReciever = new AsyncReciever();
            asyncReciever.execute();

        }catch (ConnectException connectException){
            System.out.println("Unable to connect : Connexion refused. The server may not be running.");
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private boolean checkConnection(){
        if(socket.isConnected() && !socket.isInputShutdown())
            return true;
        return false;
    }

    public void sendMessage(String message){
        try {
            if (socket == null || !socket.isConnected()) {
                connect();
            } else {
                out.write(message.getBytes());
                console.append(new StringBuilder().append(message).append("\n").toString());
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    private class AsyncReciever extends AsyncTask<String, String, String> {


        @Override
        protected void onPreExecute(){
            super.onPreExecute();
            if (checkConnection())
                connect();
        }

        @Override
        protected String doInBackground(String... strings) {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(in));
            try {
                while (checkConnection()) {
                    String s = null;
                    if ((s = bufferedReader.readLine()) != null) {
                        publishProgress(s);
                    }
                }
            }catch (Exception e){
                e.printStackTrace();
            }

            return null;
        }


        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            console.append(values[0]);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            console.setText("");
        }
    }
}
