package com.brandon.wifip2p.tcpserver;

import android.os.AsyncTask;

import com.brandon.wifip2p.tcpclient.ClientTCP;

import java.net.ServerSocket;
import java.net.Socket;

public class AcceptConnectionTask extends AsyncTask<Integer, String, ClientTCP> {

    private ClientTCP clientTCP;

    @Override
    protected ClientTCP doInBackground(Integer... integers) {
        ClientTCP clientTCP = null;
        try {
            ServerSocket serverSocket = new ServerSocket(integers[0]);
            Socket incommingSocket = serverSocket.accept();
            clientTCP = new ClientTCP(incommingSocket, null);
        }catch (Exception e){
            e.printStackTrace();
        }
        return clientTCP;
    }

    @Override
    protected void onPostExecute(ClientTCP clientTCP) {
        super.onPostExecute(clientTCP);
        this.clientTCP = clientTCP;
    }

    public ClientTCP getClientTCP(){
        return clientTCP;
    }
}
